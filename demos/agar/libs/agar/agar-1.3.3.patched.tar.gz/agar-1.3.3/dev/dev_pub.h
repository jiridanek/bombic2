/*	Public domain	*/

#ifndef _AGAR_DEV_PUBLIC_H_
#define _AGAR_DEV_PUBLIC_H_
#include <agar/dev/dev.h>
#endif
