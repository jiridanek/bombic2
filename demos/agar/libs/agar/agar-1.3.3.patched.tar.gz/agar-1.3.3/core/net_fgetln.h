/*	Public domain	*/

#include <agar/core/begin.h>
__BEGIN_DECLS
char *NS_Fgetln(FILE *, size_t *);
__END_DECLS
#include <agar/core/close.h>

