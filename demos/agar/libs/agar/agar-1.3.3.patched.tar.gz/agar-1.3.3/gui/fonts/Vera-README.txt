Contained herin is the Bitstream Vera font family.

The Copyright information is found in the COPYRIGHT.TXT file (along
with being incoporated into the fonts themselves).

The releases notes are found in the file "RELEASENOTES.TXT".

We hope you enjoy Vera!

                        Bitstream, Inc.
			The Gnome Project
