/*	Public domain	*/
/*
 * Edition tools built into the VG library.
 */

VG_ToolOps *vgTools[] = {
	&vgPointTool,
	&vgLineTool,
	&vgCircleTool,
	&vgProximityTool,
	&vgTextTool,
	&vgPolygonTool,
	NULL
};
