/*	Public domain	*/

#include <agar/vg/begin.h>
__BEGIN_DECLS
extern VG_ToolOps *vgTools[];
extern VG_ToolOps vgCircleTool;
extern VG_ToolOps vgLineTool;
extern VG_ToolOps vgPointTool;
extern VG_ToolOps vgPolygonTool;
extern VG_ToolOps vgProximityTool;
extern VG_ToolOps vgTextTool;
__END_DECLS
#include <agar/vg/close.h>
