/*	Public domain	*/

#include <agar/gui/begin.h>
__BEGIN_DECLS
Uint32	AG_ReadColor(AG_DataSource *, SDL_PixelFormat *);
void	AG_WriteColor(AG_DataSource *, SDL_PixelFormat *, Uint32);
__END_DECLS
#include <agar/gui/close.h>
