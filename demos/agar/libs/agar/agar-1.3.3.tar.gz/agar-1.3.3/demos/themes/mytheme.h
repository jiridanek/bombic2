/*	Public domain	*/

extern AG_Style myRoundedStyle;
void InitMyRoundedStyle(AG_Style *);
